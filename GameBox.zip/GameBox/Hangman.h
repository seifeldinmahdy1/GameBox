//
// Created by Seif Mahdy on 24/05/2023.
//

#ifndef GAMEBOX_HANGMAN_H
#define GAMEBOX_HANGMAN_H


void StartHangman();


#endif //GAMEBOX_HANGMAN_H
