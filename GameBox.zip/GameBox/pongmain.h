//
// Created by Seif Mahdy on 24/05/2023.
//

#ifndef GAMEBOX_PONGMAIN_H
#define GAMEBOX_PONGMAIN_H


void startPong();


#endif //GAMEBOX_PONGMAIN_H
