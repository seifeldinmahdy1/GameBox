//
// Created by Seif Mahdy on 23/05/2023.
//

#ifndef GAMEBOX_SNAKEMAIN_H
#define GAMEBOX_SNAKEMAIN_H


class snakemain {

};


#endif //GAMEBOX_SNAKEMAIN_H
