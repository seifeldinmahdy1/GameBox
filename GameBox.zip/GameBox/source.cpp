//
// Created by Seif Mahdy on 23/05/2023.
//

#include "source.h"

void StartSnakeGame() {
    Game game;
    game.runGame();
}