//
// Created by Seif Mahdy on 23/05/2023.
//

#ifndef GAMEBOX_SOURCE_H
#define GAMEBOX_SOURCE_H

#include "game.h"

void StartSnakeGame();


#endif //GAMEBOX_SOURCE_H
